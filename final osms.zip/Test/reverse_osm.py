from bs4 import BeautifulSoup
import re
import csv
import pandas as pd
import requests

ipDF=pd.read_csv('Input2.csv')
osm_list=list(ipDF["Column1.id"])[:20]
outfile=open("reverse_osm.csv","w",newline='')
csv_write=csv.writer(outfile)
csv_write.writerow(["OSM","Building Name","Address","Postal Code", "City"])
# print(osm_list)
#https://www.openstreetmap.org/way/375257537      #Sample for Taj mahal
#https://www.openstreetmap.org/node/1959174767    #

#append osm id to the url here
count=1
for osm in osm_list:
    #osm=375257537
    searchurl="https://www.openstreetmap.org/way/"+str(osm)
    source=requests.get(searchurl).text
    soup=BeautifulSoup(source,'lxml')
    osmtable=soup.find("table",attrs={"class":"browse-tag-list"})
    # print(osmtable)
    print("OSM number {}".format(count))
    count+=1
    keys=[]
    values=[]
    kv={}
    for key,val in zip(osmtable.find_all("tr"),osmtable.find_all("tr")):
        for keyf,valf in zip(key.find_all("th"),val.find_all("td")):
            # print(btf)
            kv[keyf.text.replace('\n','').strip()]=valf.text.replace('\n','').strip()
    print("Dictionary found is : {}\n-----------".format(kv))
    name=""
    city=""
    postcode=""
    final_addr=""
    if "name" in list(kv.keys()):
        name=kv["name"]
    if "addr:housenumber" in list(kv.keys()):
        final_addr+=kv["addr:housenumber"]
    if "addr:street" in list(kv.keys()):
        final_addr+=kv["addr:street"]
    if "addr:city" in list(kv.keys()):
        final_addr+=kv["addr:city"]
        city=kv["addr:city"]    
    if "addr:postcode" in list(kv.keys()):
        final_addr+=kv["addr:postcode"]
        postcode=kv["addr:postcode"]    
    if final_addr!="" or name!="" or city!="" or postcode!="":
        if final_addr=="":
            final_addr=None
        if name=="":
            name=None
        if postcode=="":
            postcode=None
        if city=="":
            city=None
        csv_write.writerow([osm,name,final_addr,postcode,city])
print("Done")    






